import React from 'react';
import { View, Text } from 'react-native';

export default function PostItem({ post }) {
  return (
    <View>
      <Text>{post.content}</Text>
    </View>
  );
}
