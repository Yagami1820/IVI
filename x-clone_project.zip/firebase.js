// firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "TA_CLE_API",
  authDomain: "ton-app.firebaseapp.com",
  projectId: "ton-app-id",
  storageBucket: "ton-app.appspot.com",
  messagingSenderId: "XXXXXXXXXXX",
  appId: "1:XXXXXXX:web:XXXXXX"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
