import React from "react";
import { View, Text, Button } from "react-native";
import { auth } from "../firebase";

export default function HomeScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Bienvenue sur x-clone !</Text>
      <Button title="Se déconnecter" onPress={() => auth.signOut()} />
    </View>
  );
}
